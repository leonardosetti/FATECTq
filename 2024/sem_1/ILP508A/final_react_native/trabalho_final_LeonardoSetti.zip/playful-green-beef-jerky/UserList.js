// UserList.js
import React from 'react';
import { FlatList, StyleSheet, View } from 'react-native';
import UserListItem from './UserListItem';

const UserList = ({ users }) => {
  return (
    <FlatList
      data={users}
      renderItem={({ item }) => <UserListItem user={item} />}
      keyExtractor={(item) => item.id.toString()}
   //   ItemSeparatorComponent={() => <View style={styles.separator} />}
    />
  );
};

const styles = StyleSheet.create({
  separator: {
    height: 1,
    backgroundColor: '#ccc',
  },
});

export default UserList;
