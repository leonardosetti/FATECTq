import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

const UserListItem = ({ user }) => {
  const [expanded, setExpanded] = useState(false);

  const handlePress = () => {
    setExpanded(!expanded);
  };

  return (
    <View style={[styles.container, expanded && styles.expandedContainer]}>
      <TouchableOpacity onPress={handlePress}>
        <View style={styles.detailRow}>
          <FontAwesome name="user" size={20} style={styles.icon} />
          <Text style={styles.name}>{user.name}</Text>
        </View>
      </TouchableOpacity>
      {expanded && (
        <View style={styles.details}>
          <View style={styles.detailRow}>
            <FontAwesome name="home" size={20} style={styles.icon} />
            <Text style={styles.detailText}>{user.address}</Text>
          </View>
          <View style={styles.detailRow}>
            <FontAwesome name="envelope" size={20} style={styles.icon} />
            <Text style={styles.detailText}>{user.email}</Text>
          </View>
          <View style={styles.detailRow}>
            <FontAwesome name="phone" size={20} style={styles.icon} />
            <Text style={styles.detailText}>{user.phone}</Text>
          </View>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 10,
    marginVertical: 5,
    marginHorizontal: 10,
    backgroundColor: '#fff', // Cor de fundo padrão
  },
  expandedContainer: {
    backgroundColor: '#f0f0f0', // Cor de fundo quando expandido
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 5,
  },
  icon: {
    marginRight: 10,
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
    color: "#3399ff", // Cor azul para o nome do usuário
  },
  details: {
    marginTop: 10,
  },
  detailText: {
    fontSize: 16,
  },
});

export default UserListItem;
