import React from 'react';
import { SafeAreaView, StyleSheet, Platform, StatusBar } from 'react-native';
import UserList from './UserList';

const users = [
{
    id: 1,
    name: 'Leonardo Setti',
    address: 'Av. Doutor Amendoim, 448 - Centro',
    email: 'leonardo.setti@fatec.sp.gov.br',
    phone: '(16)9972-8334',
  },
  {
    id: 2,
    name: 'Sandra Rosa Madalena',
    address: 'Av. Tibiriçá, 448 - Centro',
    email: 'srmadalena1985@fatec.sp.gov.br',
    phone: '(16)97555-1139',
  },{
    id: 3,
    name: 'Sidnelson Mandela',
    address: 'Rua Dionísio Aragão, 48 - Jardim das Flores',
    email: 'sidinho@emeio.com.br',
    phone: '(73)99776-4773',
  },{
    id: 4,
    name: 'Jandira Amaral de Freitas',
    address: 'Rua Apolinário Gomes, 1776 - Vila Esperança',
    email: 'jandaral@bol.com.br',
    phone: '(17)93384-9904',
  },{
    id: 5,
    name: 'Xandora de Oliveira Prado',
    address: 'Av. Independência, 96 - Centro',
    email: 'xandoli@fatec.sp.gov.br',
    phone: '(11)99855-3008',
  },{
    id: 6,
    name: 'Matheus Guaripó',
    address: 'Estrada dos Trabalhadores, 448 - Fonseca',
    email: 'theuzinho.popoi@fatec.sp.gov.br',
    phone: '(16)99881-1340',
  },
  // Adicione mais usuários conforme necessário
];

const App = () => {
  return (
    <SafeAreaView style={styles.container}>
      <UserList users={users} />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
  },
});

export default App;
