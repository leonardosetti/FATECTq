function ateraTitulo(){
    document.getElementById("bioTit").classList.add("mudaEstilo")
}