import React from 'react';
import { StyleSheet, Text, TextInput, View, ImageBackground, ScrollView } from 'react-native';

const TelaCadastro = () => {
  return (
    <ImageBackground
              source={require('./assets/imagem_fundo.jfif')}
      style={styles.background}
      resizeMode="cover"
    >
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.inputContainer}>
          <Text style={styles.label}>Nome:</Text>
          <TextInput style={styles.inputText} placeholder="Digite seu nome" />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Endereço:</Text>
          <TextInput style={styles.inputText} placeholder="Digite seu endereço" />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>Telefone:</Text>
          <TextInput style={styles.inputText} placeholder="Digite seu telefone" keyboardType="phone-pad" />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.label}>E-mail:</Text>
          <TextInput style={styles.inputText} placeholder="Digite seu e-mail" keyboardType="email-address" />
        </View>
      </ScrollView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.3)', // meio transparentinho
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    width: '100%',
  },
  label: {
    fontSize: 18,
    fontWeight: 'bold',
    marginRight: 8,
    width: 100, 
    color:'#ffe6cc',
  },
  inputText: {
    flex: 1,
    padding: 10,
    borderWidth: 1,
    borderColor: '#ffe6cc',
    borderRadius: 5,
    color:'#fff',
    backgroundColor: 'rgba(255, 166, 77, 0.3)',
  },
});

export default TelaCadastro;
