--------------------------------------------------------
	--  Exercício de fixação SQL     
	--------------------------------------------------------
	
1- Selecione todas as vendas com prazo de dias igual a 60 e código da cidade 2

2- Selecione todas as vendas com volume de vendas menor ou igual a 900

3- Selecione todas as vendas do vendedor 3 que não foram feitas na cidade com código 1

4- Selecione todas as vendas com prazo de dias igual a 60 e 
   código do produto diferente de 2

5- Selecione todas as vendas com volume de venda maior que 3000 
   na cidade com código 3 e que não seja do vendedor 4 

6- Selecione todas as vendas com volume de venda entre 900 e 1550 

7- Selecione todas as vendas com volume de venda entre 2000 e 4000 
  ordenado pela cidade da venda e pelo prazo da venda

8- Selecione todas as vendas ordenado do maior volume de venda para o menor volume

9- Selecione somente os 10 maiores registros com maior volume de venda

10- Selecione somente os 10 maiores registros com maior preço total de venda 


 
 


