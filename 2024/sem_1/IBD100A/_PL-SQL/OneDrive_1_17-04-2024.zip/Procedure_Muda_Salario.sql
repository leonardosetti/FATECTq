
create or replace  PROCEDURE MUDA_SALARIO
 AS 
  V_DATA_MUDANCA DATE;
 
 BEGIN
    UPDATE EMP
	   SET SAL = SAL + 100
	  WHERE JOB = 'VENDEDOR';
	  
	UPDATE EMP 
	   SET SAL = SAL + 50
	   WHERE JOB = 'TECNICO';
	
	UPDATE EMP
	   SET SAL = SAL + 80
	  WHERE JOB = 'ANALISTA';
	  
	  select sysdate into V_DATA_MUDANCA from dual;
      dbms_output.put_line(to_char(V_DATA_MUDANCA));
 END;
 