--------------------------------------------------------
--  Arquivo criado - Quarta-feira-Outubro-05-2022   
--------------------------------------------------------
SET DEFINE OFF;
Insert into USUARIO (CODUSER,NOME_USUARIO,CODSETOR) values ('15','MARIO GOMES','210');
Insert into USUARIO (CODUSER,NOME_USUARIO,CODSETOR) values ('25','JOSE HENRIQUE SILVA','300');
Insert into USUARIO (CODUSER,NOME_USUARIO,CODSETOR) values ('35','AM�LIA RODRIGUES SILVA','200');
Insert into USUARIO (CODUSER,NOME_USUARIO,CODSETOR) values ('45','ANDRE CONRRADO PENTES','400');
Insert into USUARIO (CODUSER,NOME_USUARIO,CODSETOR) values ('55','FABIO METIDO','400');
Insert into USUARIO (CODUSER,NOME_USUARIO,CODSETOR) values ('65','ANTONIO JOSE ANDRADA','310');
Insert into USUARIO (CODUSER,NOME_USUARIO,CODSETOR) values ('75','PAULO APARECIDO CUNHA','320');
Insert into USUARIO (CODUSER,NOME_USUARIO,CODSETOR) values ('85','SAULO PIMENTA',null);
Insert into USUARIO (CODUSER,NOME_USUARIO,CODSETOR) values ('95','ULISES HATILIO PRADO',null);


