--------------------------------------------------------
--  Arquivo criado - Ter�a-feira-Outubro-04-2022   
--------------------------------------------------------
REM INSERTING into AREA
SET DEFINE OFF;
Insert into AREA (AREA_CODIGO,NOME_AREA,TIPO_AREA) values ('10','PRODU��O','INDUSTRIAL');
Insert into AREA (AREA_CODIGO,NOME_AREA,TIPO_AREA) values ('20','COMERCIAL','VENDAS');
Insert into AREA (AREA_CODIGO,NOME_AREA,TIPO_AREA) values ('30','INVESTIMENTOS','FINANCEIRA');
Insert into AREA (AREA_CODIGO,NOME_AREA,TIPO_AREA) values ('40','PROJETOS','INDUSTRIAL');
Insert into AREA (AREA_CODIGO,NOME_AREA,TIPO_AREA) values ('50','NOVOS PRODUTOS','INDUSTRIAL');
