--------------------------------------------------------
--  Arquivo criado - Ter�a-feira-Outubro-04-2022   
--------------------------------------------------------
REM INSERTING into SETOR
SET DEFINE OFF;
Insert into SETOR (CODSETOR,DESC_SETOR,AREA_CODIGO) values ('200','COMERCIO DE PLASTICO','20');
Insert into SETOR (CODSETOR,DESC_SETOR,AREA_CODIGO) values ('210','COMERCIO DE IMPORTADOS','20');
Insert into SETOR (CODSETOR,DESC_SETOR,AREA_CODIGO) values ('310','MAQUIN�RIO','10');
Insert into SETOR (CODSETOR,DESC_SETOR,AREA_CODIGO) values ('320','COMPRESSORES','10');
Insert into SETOR (CODSETOR,DESC_SETOR,AREA_CODIGO) values ('330','METAIS PESADOS','10');
Insert into SETOR (CODSETOR,DESC_SETOR,AREA_CODIGO) values ('340','INJETORES','10');
Insert into SETOR (CODSETOR,DESC_SETOR,AREA_CODIGO) values ('230','COMERCIO EXTERIOR','20');
Insert into SETOR (CODSETOR,DESC_SETOR,AREA_CODIGO) values ('350','POL�MEROS','10');
Insert into SETOR (CODSETOR,DESC_SETOR,AREA_CODIGO) values ('400','CONTAS A PAGAR','30');
Insert into SETOR (CODSETOR,DESC_SETOR,AREA_CODIGO) values ('410','CONTABILIDADE','30');
Insert into SETOR (CODSETOR,DESC_SETOR,AREA_CODIGO) values ('300','TUBOS MET�LICCOS','10');
