	--------------------------------------------------------
	--  Arquivo criado - Ter�a-feira-Agosto-23-2022   
	--------------------------------------------------------
	REM INSERTING into ALUNO_01.EMP
	SET DEFINE OFF;
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('1','JOS�','ANALISTA','1',to_date('10/10/22','DD/MM/RR'),'2500','2','10');
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('2','FABIO','TECNICO','1',to_date('11/11/22','DD/MM/RR'),'2100','2','11');
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('30','ANDRE','VENDEDOR','1',to_date('21/08/22','DD/MM/RR'),'1200','2','10');
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('20','SAULO','VENDEDOR','1',to_date('08/08/22','DD/MM/RR'),'1300','2','10');
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('40','VITOR','analista','1',to_date('29/05/22','DD/MM/RR'),'900','2','10');
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('60','PAULO','Balconista','2',to_date('22/03/22','DD/MM/RR'),'600','3','20');
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('50','ANTONIO','Balconista','2',to_date('23/03/21','DD/MM/RR'),'800','3','30');
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('5','BANDEIRA','CONSULTOR','2',to_date('20/10/21','DD/MM/RR'),'900','3','20');
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('15','HILO','TECNICO','1',to_date('20/10/22','DD/MM/RR'),'800','2','20');
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('70','TIAGO','Vendedor','2',to_date('11/02/22','DD/MM/RR'),'1000','2','20');
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('80','CARLOS','VENDEDOR','2',to_date('23/10/21','DD/MM/RR'),'700','2','10');
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('90','JO�O','TECNICO','1',to_date('01/01/22','DD/MM/RR'),'900','2','20');
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('100','IDALGO','TECNICO','1',to_date('02/03/22','DD/MM/RR'),'1200','3','20');
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('110','TI�O','Vendedor','2',to_date('11/02/22','DD/MM/RR'),'1000','2','20');
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('120','HUMBERTO','VENDEDOR','2',to_date('23/10/21','DD/MM/RR'),'700','2','10');
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('130','TADA','TECNICO','1',to_date('01/01/22','DD/MM/RR'),'900','2','20');
	Insert into EMP (EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values ('140','OTACILIO','TECNICO','1',to_date('02/03/22','DD/MM/RR'),'1200','3','20');

	commit;
	