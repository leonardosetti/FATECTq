--------------------------------------------------------
	--  Exercício de fixação SQL     
--------------------------------------------------------
	
1- Selecione todas as vendas com prazo de dias igual a 60 e código da cidade 2

Resp:SELECT * FROM vendas WHERE PRAZO_DIAS = 60 AND CODIGO_CIDADE = 2;

2- Selecione todas as vendas com volume de vendas menor ou igual a 900

Resp: SELECT * FROM vendas WHERE VOLUME_VENDA <= 900;

3- Selecione todas as vendas do vendedor 3 que não foram feitas na cidade com código 1
Resp: SELECT * FROM vendas WHERE CODIGO_VENDEDOR = 3 AND CODIGO_CIDADE <> 1;

4- Selecione todas as vendas com prazo de dias igual a 60 e 
   código do produto diferente de 2

Resp: SELECT * FROM vendas WHERE prazo_dias = 60 and codigo_produto <> 2; 

5- Selecione todas as vendas com volume de venda maior que 3000 
   na cidade com código 3 e que não seja do vendedor 4 

  Resp:  SELECT * FROM vendas WHERE VOLUME_VENDA > 3000 AND CODIGO_CIDADE = 3 
          AND CODIGO_VENDEDOR <> 4;

6- Selecione todas as vendas com volume de venda entre 900 e 1550 

Resp: SELECT codigo_cliente, volume_venda, codigo_cidade FROM vendas 
        WHERE VOLUME_VENDA between 900 AND 1550
      ORDER BY VOLUME_VENDA, codigo_cidade;
	  
	  SELECT codigo_cliente, volume_venda, codigo_cidade FROM vendas 
        WHERE VOLUME_VENDA >= 900 AND VOLUME_VENDA <= 1550
      ORDER BY VOLUME_VENDA, codigo_cidade;
	  
7- Selecione todas as vendas com volume de venda entre 2000 e 4000 
  ordenado pela cidade da venda e pelo prazo da venda

Resp: SELECT codigo_cliente, volume_venda, codigo_cidade FROM vendas 
        WHERE VOLUME_VENDA between 2000 AND 4000
		 order by codigo_cidade, PRAZO_DIAS;
  
8- Selecione todas as vendas ordenado do maior volume de venda para o menor volume

Resp: select * from VENDAS ORDER BY VOLUME_VENDA DESC;

9- Selecione somente os 10 maiores registros com maior volume de venda

RESP: select CODIGO, volume_venda from    
     (select codigo, VOLUME_VENDA from ALUNO_EDU.vendas order by volume_venda desc)
  where rownum < 11;

10- Selecione somente os 10 maiores registros com maior preço total de venda 
 RESP.: 
 select CODIGO, TOT1 from    
     (select codigo, VOLUME_VENDA * PRECO_VENDA AS TOT1 
	     from ALUNO_EDU.vendas order by TOT1 desc)
  where rownum < 11;
  

11 - Alterar para prazo de 90 dias onde o codigo do produto = 6 e volume > 4000

UPDATE vendas
   SET prazo_dias = 90 
   WHERE CODIGO_PRODUTO = 6 AND volume_venda > 4000;
   
   COMMIT;
   
 12 - Informar a quantidade de registros onde o volume > 2000 e codigo_cidade = 3 
      e produto = 3
 
 SELECT COUNT(*) FROM vendas WHERE CODIGO_PRODUTO = 3 
 AND VOLUME_VENDA > 2000 AND CODIGO_cidade = 3






 
 


