set echo on;
set linesize 1000;
set serveroutput on;

truncate table Tab_Analisa_Aumento;
select '--- Inicio da Rotina PL/SQL ---' from dual;

Declare
   v_EMPNO    EMP.EMPNO%TYPE;
   v_NOME     EMP.ENAME%TYPE;
   v_JOB      EMP.JOB%TYPE;
   v_SAL      EMP.SAL%TYPE;
   v_COMM      EMP.COMM%TYPE;

  Begin
     FOR Dados_Emp in
        (select DISTINCT EMPNO, ENAME, JOB, SAL, COMM from EMP )
	  loop
	      v_EMPNO := Dados_Emp.EMPNO;
          v_NOME := Dados_Emp.ENAME;
          v_JOB := Dados_Emp.JOB;
		  v_SAL := Dados_Emp.SAL;
		  v_COMM := Dados_Emp.COMM;
            If v_JOB = 'Balconista' and v_SAL < 1000
		       then
			      insert into Tab_Analisa_Aumento (EMPNO, ENAME, JOB, SAL, COMM) VALUES (v_EMPNO, v_NOME, v_JOB, v_SAL, v_COMM);
		    End If;
        END LOOP;
     
	 commit;
   
 END;
 /
 